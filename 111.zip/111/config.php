<?php 

define('DB_USER', 'postgres');
define('DB_PASS', '123');
define('DB_PORT', '5432');
define('DB_HOST', '172.19.0.3');
define('DB_NAME', 'kursach');